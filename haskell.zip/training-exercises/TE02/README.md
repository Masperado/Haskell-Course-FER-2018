# PUH Training: TE02

Welcome to your second Haskell training. This one is gonna be a bit different.

## Mandatory part

For the mandatory part of this Training Exercise you have to write function type signatures for every function you did in TE01.

Do this in the `training-exercises/TE01/TrainingExercises.hs` file and submit a Merge Request (or, if you still haven't finished TE01, do this along). Don't forget to assign it to your TA.

## Extra part

The extra segment of the second Training Exercise is meant to fully prepare you for your upcoming level battle. You do not have to do it, but if you want to practice a bit more before taking on the battle, feel free to give it your best.

As always, ask your TA if you need any help.
