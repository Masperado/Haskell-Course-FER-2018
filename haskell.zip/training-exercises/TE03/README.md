# PUH Training: TE03

Welcome to your third Haskell training. Get ready to rumble. Where will you let the pattern matching lead you?

## Exercises

You should know the drill by now - solve the exercises in `TrainingExercises.hs`,
run the tests with Cabal, push to `training-03`, create a Merge Request, and assign it to your TA.

Keep in mind that **all exposed functions must have type signatures** (helper functions that are defined in local definitions don't)!

As always, ask your TA if you need any help.
